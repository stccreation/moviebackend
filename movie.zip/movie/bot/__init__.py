
from pyrogram import Client

Bot = Client(
    name="Movie",
    api_id=1383392,
    api_hash='f7ec7a1bc8c41c6fe23c2706c67eda7c',
    sleep_threshold=60,
    workers=4)